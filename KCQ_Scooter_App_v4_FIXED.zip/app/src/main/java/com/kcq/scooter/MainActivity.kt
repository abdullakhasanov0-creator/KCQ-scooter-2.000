package com.kcq.scooter

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

@SuppressLint("MissingPermission")
class BleManager(private val context: Context) {
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager.adapter
    private var bluetoothGatt: BluetoothGatt? = null
    private var txCharacteristic: BluetoothGattCharacteristic? = null
    private var lastDeviceAddress: String? = null
    private val handler = Handler(Looper.getMainLooper())

    private val SERVICE_UUID = UUID.fromString("6e400001-c358-11e3-955e-0002a5d5c51b")
    private val CHAR_TX_UUID = UUID.fromString("6e400002-c358-11e3-955e-0002a5d5c51b")
    private val CHAR_RX_UUID = UUID.fromString("6e400003-c358-11e3-955e-0002a5d5c51b")

    val isConnected = mutableStateOf(false)
    val isScanning = mutableStateOf(false)
    val foundDevices = mutableStateListOf<BluetoothDevice>()
    val speedKmh = mutableFloatStateOf(0f)
    val batteryPercent = mutableIntStateOf(85)
    val voltage = mutableFloatStateOf(41.2f)
    val tempCelsius = mutableIntStateOf(28)
    val isLocked = mutableStateOf(false)
    val isLightOn = mutableStateOf(false)
    val rideMode = mutableIntStateOf(2)
    val useMph = mutableStateOf(false)
    val errorCode = mutableIntStateOf(0)

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            if (device.name != null && foundDevices.none { it.address == device.address }) {
                foundDevices.add(device)
            }
        }
    }

    fun startScan() {
        foundDevices.clear()
        isScanning.value = true
        adapter?.bluetoothLeScanner?.startScan(scanCallback)
        handler.postDelayed({ stopScan() }, 10000)
    }

    fun stopScan() {
        isScanning.value = false
        adapter?.bluetoothLeScanner?.stopScan(scanCallback)
    }

    fun connect(address: String) {
        stopScan()
        lastDeviceAddress = address
        val device = adapter?.getRemoteDevice(address)
        bluetoothGatt = device?.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        lastDeviceAddress = null
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        isConnected.value = false
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                isConnected.value = true
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                isConnected.value = false
                if (lastDeviceAddress != null) {
                    handler.postDelayed({ lastDeviceAddress?.let { connect(it) } }, 2000)
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val service = gatt.getService(SERVICE_UUID) ?: gatt.services.firstOrNull()
            txCharacteristic = service?.getCharacteristic(CHAR_TX_UUID)
            val rxChar = service?.getCharacteristic(CHAR_RX_UUID)
            if (rxChar != null) gatt.setCharacteristicNotification(rxChar, true)
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val data = characteristic.value
            if (data.size >= 8 && data[0] == 0x5A.toByte() && data[1] == 0xA5.toByte()) {
                val cmd = data[4].toInt() and 0xFF
                if (cmd == 0xB0) {
                    batteryPercent.intValue = data[5].toInt() and 0xFF
                    val rawSpeed = ((data[6].toInt() and 0xFF) shl 8) or (data[7].toInt() and 0xFF)
                    speedKmh.floatValue = rawSpeed / 100f
                }
            }
        }
    }

    fun sendCommand(cmd: Byte, param: Byte) {
        val payload = byteArrayOf(0x5A.toByte(), 0xA5.toByte(), 0x02, 0x20, cmd, param)
        var sum = 0
        for (i in 2 until payload.size) sum += (payload[i].toInt() and 0xFF)
        val crc = sum.inv() and 0xFFFF
        val packet = payload + byteArrayOf((crc and 0xFF).toByte(), ((crc shr 8) and 0xFF).toByte())
        txCharacteristic?.let {
            it.value = packet
            bluetoothGatt?.writeCharacteristic(it)
        }
    }

    fun toggleLight() { isLightOn.value = !isLightOn.value; sendCommand(0x7D, if (isLightOn.value) 0x01 else 0x00) }
    fun toggleLock() { isLocked.value = !isLocked.value; sendCommand(if (isLocked.value) 0x70 else 0x71, 0x01) }
    fun setMode(mode: Int) { rideMode.intValue = mode; sendCommand(0x75, mode.toByte()) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bleManager = BleManager(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF121212)) {
                    ScooterApp(bleManager)
                }
            }
        }
    }
}

@Composable
fun ScooterApp(ble: BleManager) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showScanDialog by remember { mutableStateOf(false) }

    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        ble.startScan()
        showScanDialog = true
    }

    Scaffold(
        topBar = {
            Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("KCQ MAX PRO", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Button(
                    onClick = { if (ble.isConnected.value) ble.disconnect() else launcher.launch(permissions) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (ble.isConnected.value) Color(0xFF2E7D32) else Color(0xFF1976D2))
                ) { Text(if (ble.isConnected.value) "Подключено" else "Поиск BLE") }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF1E1E1E)) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Speed, null) }, label = { Text("Приборы") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Управление") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Build, null) }, label = { Text("Диагностика") })
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> DashboardScreen(ble)
                1 -> ControlScreen(ble)
                2 -> DiagnosticsScreen(ble)
            }
        }
        if (showScanDialog) {
            AlertDialog(
                onDismissRequest = { showScanDialog = false; ble.stopScan() },
                title = { Text("Выберите самокат") },
                text = {
                    LazyColumn(modifier = Modifier.heightIn(max = 250.dp)) {
                        items(ble.foundDevices) { device ->
                            Text("${device.name ?: "Unknown"} (${device.address})", modifier = Modifier.fillMaxWidth().clickable { ble.connect(device.address); showScanDialog = false }.padding(12.dp))
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showScanDialog = false; ble.stopScan() }) { Text("Закрыть") } }
            )
        }
    }
}

@Composable
fun DashboardScreen(ble: BleManager) {
    val speed = if (ble.useMph.value) ble.speedKmh.floatValue * 0.621371f else ble.speedKmh.floatValue
    val unit = if (ble.useMph.value) "MPH" else "КМ/Ч"
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
        Surface(shape = CircleShape, color = Color(0xFF1E1E1E), modifier = Modifier.size(240.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(String.format("%.1f", speed), fontSize = 64.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00E5FF))
                Text(unit, fontSize = 18.sp, color = Color.Gray)
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            InfoCard("Батарея", "${ble.batteryPercent.intValue}%")
            InfoCard("Напряжение", "${ble.voltage.floatValue} V")
            InfoCard("Темп.", "${ble.tempCelsius.intValue}°C")
        }
    }
}

@Composable
fun InfoCard(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.Gray, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ControlScreen(ble: BleManager) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Режим езды", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ECO", "DRIVE", "SPORT (55)").forEachIndexed { index, label ->
                Button(
                    onClick = { ble.setMode(index) }, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = if (ble.rideMode.intValue == index) Color(0xFF00E5FF) else Color(0xFF2C2C2C), contentColor = if (ble.rideMode.intValue == index) Color.Black else Color.White)
                ) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        }
        Button(onClick = { ble.toggleLight() }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = if (ble.isLightOn.value) Color(0xFFFFB300) else Color(0xFF2C2C2C))) {
            Icon(Icons.Default.Lightbulb, null); Spacer(Modifier.width(8.dp)); Text(if (ble.isLightOn.value) "Фара: ВКЛ" else "Фара: ВЫКЛ")
        }
        Button(onClick = { ble.toggleLock() }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = if (ble.isLocked.value) Color(0xFFD32F2F) else Color(0xFF2C2C2C))) {
            Icon(if (ble.isLocked.value) Icons.Default.Lock else Icons.Default.LockOpen, null); Spacer(Modifier.width(8.dp)); Text(if (ble.isLocked.value) "Блокировка: АКТИВНА" else "Блокировка: СНЯТА")
        }
        Row(modifier = Modifier.fillMaxWidth().background(Color(0xFF1E1E1E), RoundedCornerShape(12.dp)).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Единицы измерения (MPH)", color = Color.White)
            Switch(checked = ble.useMph.value, onCheckedChange = { ble.useMph.value = it })
        }
    }
}

@Composable
fun DiagnosticsScreen(ble: BleManager) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Состояние системы", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Код ошибки контроллера: ${if (ble.errorCode.intValue == 0) "Ошибок нет (0x00)" else "Ошибка #${ble.errorCode.intValue}"}", color = Color(0xFF4CAF50))
                Text("Напряжение батареи: ${ble.voltage.floatValue} V", color = Color.White)
                Text("Температура контроллера: ${ble.tempCelsius.intValue} °C", color = Color.White)
                Text("Протокол: KCQ / Ninebot BLE UART", color = Color.Gray)
            }
        }
    }
}
