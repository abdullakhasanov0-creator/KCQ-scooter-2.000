# KCQ Scooter App

Android-приложение KCQ MAX PRO на Kotlin + Jetpack Compose.

## Сборка через GitHub Actions

1. Загрузите содержимое архива в корень GitHub-репозитория.
2. Откройте вкладку **Actions**.
3. Выберите workflow **Build Android APK**.
4. Нажмите **Run workflow** или отправьте изменения в ветку `main`/`master`.
5. После успешной сборки откройте запуск workflow и скачайте artifact **KCQ-Scooter-APK**.

Workflow использует:
- JDK 17
- Android SDK Platform 34 и Build Tools 34.0.0
- Gradle 8.5
- Android Gradle Plugin 8.2.2
- Kotlin 1.9.22

Лицензии Android SDK принимаются автоматически через `setup-android` и дополнительный вызов
`sdkmanager --licenses`. Это покрывает в том числе лицензию `android-googletv-license`,
если она присутствует среди лицензий SDK на runner.

## Важное замечание о проверке

Архив, который был предоставлен для исправления, содержал только семь файлов проекта:
Gradle-конфигурацию, манифест, workflow и `MainActivity.kt`. В нём не было Gradle Wrapper,
тестов, ресурсов или других исходников. Поэтому они не могли быть восстановлены без
дополнительного исходного архива. Workflow использует Gradle 8.5, устанавливаемый GitHub
Actions, и не зависит от отсутствующего `gradlew`.

Сборка APK должна быть окончательно подтверждена запуском GitHub Actions в вашем репозитории.
В этой среде полноценная сборка Android не выполнялась: локальный Gradle/Android SDK отсутствует.
